import javax.swing.ImageIcon;

public class Boss extends Sprite{
    private Bomb bomb;
    private final String boss = "/img/boss.png";

    /*
     * Constructor
     */
    public Boss(int x, int y) {
        this.x = x;
        this.y = y;

        bomb = new Bomb(x, y);
        ImageIcon ii = new ImageIcon(this.getClass().getResource(boss));
        setImage(ii.getImage());

    }




    public void act(int direction) {
        this.x += direction;
    }

    /*
     * Getters & Setters
     */

    public Bomb getBomb() {
        return bomb;
    }
}

