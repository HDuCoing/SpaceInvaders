READ ME

SPACE INVADERS 
By Holly DuCoing, Liam Brennan, Piyathi Munasinghe


# The game
Space Invaders is an arcade video game, The player is a space ship that shoots at aliens in the sky. They are about to save the Earth from invasion of evil space invaders.


# Controls
Go Left: Left Arrowkey;

Go Right: Right Arrowkey;

Shot: Spacebar;



# Have fun! ;)


# Game Screens
