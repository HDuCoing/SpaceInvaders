//The base for the game, interface was used. 

public interface Commons {

	public static final int BOARD_WIDTH = 640;//the width of the game screen
    public static final int BOARD_HEIGTH = 480;//the height of the game screen
    public static final int GROUND = 440;//the length of the ground
    public static final int BOMB_HEIGHT = 5; //Height of the bomb dropped
    public static final int ALIEN_HEIGHT = 30; // height for the alien
    public static final int ALIEN_WIDTH = 30;	//width for the alien
    public static final int BORDER_RIGHT = 30; //the size of the border
    public static final int BORDER_LEFT = 30;
    public static final int GO_DOWN = 25;//bullets shot by the aliens
    public static final int NUMBER_OF_ALIENS_TO_DESTROY = 24;//how many aliens spawn at the start
    public static final int CHANCE = 5;
    public static final int DELAY = 17;
    public static final int PLAYER_WIDTH = 30;// size of the playerS
    public static final int PLAYER_HEIGHT = 30;

}
